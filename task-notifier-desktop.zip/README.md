
# Task Notifier – Desktop (Electron)

Lightweight desktop app for on-time task reminders with native notifications and sound.

## Quick start

1. Install **Node.js LTS** (v18+ recommended).
2. Open a terminal inside this folder and run:

```bash
npm install
npm start
```

This launches the app with a tray icon. Closing the window hides it to tray so reminders continue.

## Build installers

```bash
npm run dist
```

Electron Builder will create installers under the `dist/` folder:
- **Windows**: NSIS installer (.exe)
- **macOS**: DMG (.dmg)
- **Linux**: AppImage/Deb (as configured)

> To customize app name, icons, and targets, edit the `build` section in `package.json` and replace icons in `assets/`.

## Notes
- Notifications use the HTML5 `Notification` API from the renderer; timers run even when the window is hidden (background throttling disabled).
- Data is stored locally via `localStorage`.
- Sound alerts support built-in tones and custom audio files, with optional looping until you dismiss.

## Troubleshooting
- **Windows notifications** not showing app name? The app sets `app.setAppUserModelId('com.mdsazzad.tasknotifier')` in `main.js`.
- **Audio autoplay**: Click **Test sound** once to satisfy any autoplay restrictions.
- **Start on login**: Consider using a tool like `electron-auto-launch` if you want auto-start (not included by default).

Enjoy!
