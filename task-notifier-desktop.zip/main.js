
const { app, BrowserWindow, nativeImage, Tray, Menu, shell } = require('electron');
const path = require('path');

let mainWindow = null;
let tray = null;

// Helps Windows notifications show app name
app.setAppUserModelId('com.mdsazzad.tasknotifier');

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 720,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#0f172a',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      backgroundThrottling: false
    }
  });

  mainWindow.loadFile('index.html');

  mainWindow.on('close', (e) => {
    // Hide to tray instead of quitting
    if (!app.isQuiting) {
      e.preventDefault();
      mainWindow.hide();
    }
  });
}

function createTray(){
  const iconPath = path.join(__dirname, 'assets', process.platform === 'darwin' ? 'iconTemplate.png' : 'icon.png');
  const image = nativeImage.createFromPath(iconPath);
  tray = new Tray(image.isEmpty() ? undefined : image);
  
  const loginItem = app.getLoginItemSettings();
  let startOnLoginEnabled = loginItem && loginItem.openAtLogin;
  const contextMenu = Menu.buildFromTemplate([
    { label: 'Show Task Notifier', click: () => { mainWindow.show(); } },
    { type: 'separator' },
    { label: (startOnLoginEnabled ? 'Disable' : 'Enable') + ' Start at login', click: () => {
        startOnLoginEnabled = !startOnLoginEnabled;
        app.setLoginItemSettings({ openAtLogin: startOnLoginEnabled, path: process.execPath });
        const msg = startOnLoginEnabled ? 'Enabled start at login' : 'Disabled start at login';
        tray.displayBalloon ? tray.displayBalloon({ title: 'Task Notifier', content: msg }) : tray.setToolTip('Task Notifier – ' + msg);
        // Rebuild menu to reflect label change
        createTray();
      }
    },
    { label: 'Open Windows Notifications settings', click: () => {
        // Opens Windows 11 Notifications settings page
        shell.openExternal('ms-settings:notifications');
      }
    },
    { type: 'separator' },
    { label: 'Quit', click: () => { app.isQuiting = true; app.quit(); } }
  ]);

  tray.setToolTip('Task Notifier');
  tray.setContextMenu(contextMenu);
  tray.on('double-click', () => mainWindow.show());
}

app.whenReady().then(() => {
  // Start-at-login default handled below
  createWindow();
  createTray();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
    else mainWindow.show();
  });
});

app.on('window-all-closed', function () {
  // Keep running in background (tray) on all platforms
  // If you prefer macOS behavior (stay until quit), comment this line
  // and remove tray close override.
  // Do nothing here to keep timers alive.
});


app.whenReady().then(() => {
  // Ensure Start at login is enabled by default
  try {
    const current = app.getLoginItemSettings();
    if (!current.openAtLogin) {
      app.setLoginItemSettings({ openAtLogin: true, path: process.execPath });
    }
  } catch (e) { /* ignore */ }
});
