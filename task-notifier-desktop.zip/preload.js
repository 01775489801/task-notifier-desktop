
// Preload can expose limited APIs if needed in the future.
// Currently, we rely on standard Web APIs (Notifications, localStorage, Audio) in the renderer.
